import viewer.Menu;

public class Main {

    public static void main(String[] args) {
        Menu menuObj = new Menu();
        menuObj.menuLoop();
    }
}