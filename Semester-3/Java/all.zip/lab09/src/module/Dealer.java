package module;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Dealer extends Employee implements Serializable {
    private final int commission;
    private final int monthlyCommissionLimit;

    public Dealer(String pesel, String firstName, String lastName, String position,
                  int salary, String phoneNumber, int commission,
                  int monthlyCommissionLimit) {
        super(pesel, firstName, lastName, position, salary, phoneNumber);
        this.commission = commission;
        this.monthlyCommissionLimit = monthlyCommissionLimit;
    }

    @Override
    public String getEmployeeType() {
        return "module.Dealer";
    }

    @Override
    public String additionalInfo() {
        return "Commission: %d\nMonthly Commission Limit: %d\n".formatted(commission,
                monthlyCommissionLimit);
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
    }
}

