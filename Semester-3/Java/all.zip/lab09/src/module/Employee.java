package module;

import java.io.Serializable;

public abstract class Employee implements Serializable {

    private String pesel;
    private String firstName;
    private String lastName;
    private String position;
    private int salary;
    private String phoneNumber;

    public String getPesel() {
        return pesel;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPosition() {
        return position;
    }

    public int getSalary() {
        return salary;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Employee(String pesel, String firstName, String lastName, String position,
                    int salary, String phoneNumber) {
        this.pesel = pesel;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
    }

    public abstract String getEmployeeType();

    public abstract String additionalInfo();

    @Override
    public String toString() {
        return "Employee Type: " + getEmployeeType() + "\n" +
                "PESEL: " + getPesel() + "\n" +
                "First Name: " + getFirstName() + "\n" +
                "Last Name: " + getLastName() + "\n" +
                "Position: " + getPosition() + "\n" +
                "Salary: " + getSalary() + "\n" +
                "Phone Number: " + getPhoneNumber() + "\n" +
                additionalInfo();
    }
}

