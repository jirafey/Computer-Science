package module;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public class Logic {
    private Map<String, Employee> employeeMap = new HashMap<>();
    private String fileName = "employees.txt";
    private char archiveType;

    public void add(Employee employee) {
        employeeMap.put(employee.getPesel(), employee);
    }

    public void remove(Employee employee) {
        employeeMap.remove(employee.getPesel());
    }

    public int getSize() {
        return employeeMap.size();
    }

    public Employee getElementByPesel(String pesel){
        return employeeMap.get(pesel);
    }

    public void backupToFile(char archiveType) {
        try {
            switch (archiveType) {
                case 'Z':
                    try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(fileName + ".zip"));
                         ObjectOutputStream out = new ObjectOutputStream(zos)) {
                        zos.putNextEntry(new ZipEntry("employees"));
                        out.writeObject(employeeMap);
                        zos.closeEntry();
                    }
                    break;
                case 'G':
                    try (GZIPOutputStream gzos = new GZIPOutputStream(new FileOutputStream(fileName + ".gz"));
                         ObjectOutputStream out = new ObjectOutputStream(gzos)) {
                        out.writeObject(employeeMap);
                    }
                    break;
                default:
                    System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
            }
        } catch (IOException e) {
            System.out.println("Error saving employees: " + e.getMessage());
        }
    }

    public void loadFromFile(char archiveType) {
        this.archiveType = archiveType;
        File file;
        switch (archiveType) {
            case 'Z':
                file = new File(fileName + ".zip");
                break;
            case 'G':
                file = new File(fileName + ".gz");
                break;
            default:
                System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
                return;
        }
        if (!file.exists() || file.length() == 0) {
            System.out.println("File does not exist or is empty.");
            return;
        }
        try {
            switch (archiveType) {
                case 'Z':
                    try (ZipInputStream zis = new ZipInputStream(new FileInputStream(file));
                         ObjectInputStream in = new ObjectInputStream(zis)) {
                        Object obj = in.readObject();
                        if (obj instanceof HashMap<?, ?>) {
                            HashMap<?, ?> map = (HashMap<?, ?>) obj;
                            for (Map.Entry<?, ?> entry : map.entrySet()) {
                                if (entry.getKey() instanceof String && entry.getValue() instanceof Employee) {
                                    employeeMap.put((String) entry.getKey(), (Employee) entry.getValue());
                                }
                            }
                        } else {
                            System.out.println("File does not contain a valid employee map.");
                        }
                    }
                    break;
                case 'G':
                    try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(file));
                         ObjectInputStream in = new ObjectInputStream(gzis)) {
                        Object obj = in.readObject();
                        if (obj instanceof HashMap<?, ?>) {
                            HashMap<?, ?> map = (HashMap<?, ?>) obj;
                            for (Map.Entry<?, ?> entry : map.entrySet()) {
                                if (entry.getKey() instanceof String && entry.getValue() instanceof Employee) {
                                    employeeMap.put((String) entry.getKey(), (Employee) entry.getValue());
                                }
                            }
                        } else {
                            System.out.println("File does not contain a valid employee map.");
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading employees: " + e.getMessage());
        }
    }

    public void printEmployeeList() {
        for (Employee employee : employeeMap.values()) {
            System.out.println(employee);
        }
    }
}