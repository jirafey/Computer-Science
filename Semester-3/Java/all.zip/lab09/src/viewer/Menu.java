package viewer;

import controller.Controller;
import java.util.Scanner;

public class Menu {
    private final Controller controller = new Controller();
    private final Scanner sc = new Scanner(System.in);

    public void menuLoop() {
        while (true) {
            System.out.println("""
                    Menu:
                    [1] Print the employee list
                    [2] Add an employee
                    [3] Remove an employee
                    [4] Backup employee list to file
                    [5] Exit
                    """);

            switch (sc.nextInt()) {
                case 1 -> controller.printEmployeeList();
                case 2 -> controller.addEmployee();
                case 3 -> controller.removeEmployee();
                case 4 -> backupOrLoadEmployeeList();
                case 5 -> System.exit(0);
            }
            sc.nextLine();
        }
    }

    public void backupOrLoadEmployeeList() {
        System.out.println("Do you want to [1] Backup or [2] Load the employee list?");
        switch (sc.nextInt()) {
            case 1 -> backupEmployeeList();
            case 2 -> loadEmployeeList();
            default -> System.out.println("Invalid option. Please try again.");
        }
    }

    public void backupEmployeeList() {
        System.out.println("Do you want to save the employee list to a file? [1] Yes [2] No");
        switch (sc.nextInt()) {
            case 1 -> {
                System.out.println("Choose the type of archive: [Z] ZIP [G] GZIP");
                char archiveType = sc.next().charAt(0);
                controller.backupToFile(archiveType);
            }
            case 2 -> {
                System.out.println("Employee list not saved.");
                System.exit(0);
            }
            default -> System.out.println("Invalid option. Please try again.");
        }
    }
    public void loadEmployeeList() {
        System.out.println("Do you want to load the employee list from a file? [1] Yes [2] No");
        switch (sc.nextInt()) {
            case 1 -> {
                System.out.println("Choose the type of archive: [Z] ZIP [G] GZIP");
                char archiveType = sc.next().charAt(0);
                controller.loadFromFile(archiveType);
                controller.printEmployeeList();
            }
            case 2 -> {
                System.out.println("Employee list not loaded.");
                System.exit(0);
            }
            default -> System.out.println("Invalid option. Please try again.");
        }
    }
}