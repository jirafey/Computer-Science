import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
//         Step 1: Create a Message object
        Message message = new Message("asdasda World!");

        // Step 2: Write the Message object to a file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("message.ser"))) {
            oos.writeObject(message);
        }

        // Step 3: Compress the serialized file into a zip file
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream("message.zip"));
             FileInputStream fis = new FileInputStream("message.ser")) {
            zos.putNextEntry(new ZipEntry("message.ser"));
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zos.write(bytes, 0, length);
            }
        }
        // Step 4: Extract the zip file
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream("message.zip"));
             FileOutputStream fos = new FileOutputStream("extracted_message.ser")) {
            ZipEntry zipEntry = zis.getNextEntry();
            byte[] bytes = new byte[1024];
            int length;
            while ((length = zis.read(bytes)) >= 0) {
                fos.write(bytes, 0, length);
            }
        }

        // Step 5: Read the serialized file and print the message
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("extracted_message.ser"))) {
            Message extractedMessage = (Message) ois.readObject();
            System.out.println(extractedMessage.getText());
        }
    }
}