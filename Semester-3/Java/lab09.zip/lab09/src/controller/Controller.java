package controller;

import module.*;

import java.util.Scanner;

public class Controller {

    private final Logic logicObj = new Logic();
    private final Scanner sc = new Scanner(System.in);

    public void addEmployee() {
        Employee employee = createEmployee();
        if (employee != null) {
            logicObj.add(employee);
        }
    }

    public void removeEmployee() {
        String peselToRemove = getInputString("Enter the PESEL of the employee to remove:");
        Employee employeeToRemove = searchEmployeeByPesel(peselToRemove);
        if (employeeToRemove != null) {
            logicObj.remove(employeeToRemove);
            System.out.println("Employee removed successfully.");
        } else {
            System.out.println("Employee with given PESEL not found.");
        }
    }

    private Employee createEmployee() {
        char employeeType = getInputChar("Add an employee: [C]CEO/[D]Dealer");
        sc.nextLine();
        String pesel = getInputString("Enter PESEL:");
        String firstName = getInputString("Enter first name:");
        String lastName = getInputString("Enter last name:");
        String position = getInputString("Enter position:");
        int salary = getInputInt("Enter salary:");
        sc.nextLine();
        String phoneNumber = getInputString("Enter phone number:");

        if (employeeType == 'C') {
            String cardNumber = getInputString("Enter card number:");
            int bonus = getInputInt("Enter bonus:");
            sc.nextLine();
            int monthlyCostLimit = getInputInt("Enter monthly cost limit:");
            sc.nextLine();
            return new CEO(pesel, firstName, lastName, position, salary, phoneNumber, cardNumber, bonus, monthlyCostLimit);
        } else if (employeeType == 'D') {
            int commission = getInputInt("Enter commission:");
            sc.nextLine();
            int monthlyCommissionLimit = getInputInt("Enter monthly commission limit:");
            sc.nextLine();
            return new Dealer(pesel, firstName, lastName, position, salary, phoneNumber, commission, monthlyCommissionLimit);
        }
        return null;
    }

    private Employee searchEmployeeByPesel(String pesel) {
        for (int i = 0; i < logicObj.getSize(); i++) {
            if (logicObj.getElementByID(i).getPesel().equals(pesel)) {
                return logicObj.getElementByID(i);
            }
        }
        return null;
    }

    public void printEmployeeList() {
        for (int i = 0; i < logicObj.getSize(); i++) {
            System.out.println(logicObj.getElementByID(i));
        }
    }

    private String getInputString(String prompt) {
        System.out.println(prompt);
        return sc.nextLine();
    }

    public int getInputInt(String prompt) {
        System.out.println(prompt);
        return sc.nextInt();
    }

    private char getInputChar(String s) {
        System.out.println("Add an employee: [C]CEO/[D]Dealer");
        return sc.next().charAt(0);
    }

    public void backupToFile(char archiveType) {
        logicObj.backupToFile(archiveType);
    }

    public void loadFromFile(char archiveType) {
        logicObj.loadFromFile();
    }
}