package module;

public class CEO extends Employee {
    private int bonus;
    private int monthlyCostLimit;
    private String cardNumber;

    public CEO(String pesel, String firstName, String lastName, String position,
               int salary, String phoneNumber, String cardNumber, int bonus,
               int monthlyCostLimit) {
        super(pesel, firstName, lastName, position, salary, phoneNumber);
        this.bonus = bonus;
        this.monthlyCostLimit = monthlyCostLimit;
        this.cardNumber = cardNumber;
    }

    @Override
    public String getEmployeeType() {
        return "module.CEO";
    }

    @Override
    public String additionalInfo() {
        return "Card Number: %s\nBonus: %d\nMonthly Cost Limit: %d\n".formatted(cardNumber,
                bonus, monthlyCostLimit);
    }
}
