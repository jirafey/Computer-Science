package module;

public class Dealer extends Employee {
    private final int commission;
    private final int monthlyCommissionLimit;

    public Dealer(String pesel, String firstName, String lastName, String position,
                  int salary, String phoneNumber, int commission,
                  int monthlyCommissionLimit) {
        super(pesel, firstName, lastName, position, salary, phoneNumber);
        this.commission = commission;
        this.monthlyCommissionLimit = monthlyCommissionLimit;
    }

    @Override
    public String getEmployeeType() {
        return "module.Dealer";
    }

    @Override
    public String additionalInfo() {
        return "Commission: %d\nMonthly Commission Limit: %d\n".formatted(commission,
                monthlyCommissionLimit);
    }
}
