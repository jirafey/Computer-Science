package module;

import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.zip.*;

public class Logic {
    private LinkedList<Employee> employeeList = new LinkedList<>();
    private final String fileName = "employees.txt";
    private char archiveType;

    public void add(Employee employee) {
        employeeList.add(employee);
    }

    public void remove(Employee employee) {
        employeeList.remove(employee);
    }

    public int getSize() {
        return employeeList.size();
    }

    public Employee getElementByID(int id){
        return employeeList.get(id);
    }

    public void loadFromFile(char archiveType) {
        this.archiveType = archiveType;
        try {
            switch (archiveType) {
                case 'Z':
                    try (ZipInputStream zis = new ZipInputStream(new FileInputStream(fileName + ".zip"));
                         Scanner scanner = new Scanner(zis)) {
                        ZipEntry ze = zis.getNextEntry();
                        while (ze != null) {
                            readEmployees(scanner);
                            ze = zis.getNextEntry();
                        }
                    }
                    break;
                case 'G':
                    try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(fileName + ".gz"));
                         Scanner scanner = new Scanner(gzis)) {
                        readEmployees(scanner);
                    }
                    break;
                default:
                    System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
            }
        } catch (IOException e) {
            System.out.println("Error loading employees: " + e.getMessage());
        }
    }

    private void readEmployees(Scanner scanner) {
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.startsWith("Employee Type: ")) {
                String employeeType = line.substring("Employee Type: ".length());
                String pesel = scanner.nextLine().substring("PESEL: ".length());
                String firstName = scanner.nextLine().substring("First Name: ".length());
                String lastName = scanner.nextLine().substring("Last Name: ".length());
                String position = scanner.nextLine().substring("Position: ".length());
                int salary = Integer.parseInt(scanner.nextLine().substring("Salary: ".length()));
                String phoneNumber = scanner.nextLine().substring("Phone Number: ".length());
                Employee employee;
                if (employeeType.equals("module.CEO")) {
                    String cardNumber = scanner.nextLine().substring("Card Number: ".length());
                    int bonus = Integer.parseInt(scanner.nextLine().substring("Bonus: ".length()));
                    int monthlyCostLimit = Integer.parseInt(scanner.nextLine().substring("Monthly Cost Limit: ".length()));
                    employee = new CEO(pesel, firstName, lastName, position, salary, phoneNumber, cardNumber, bonus, monthlyCostLimit);
                } else if (employeeType.equals("module.Dealer")) {
                    int commission = Integer.parseInt(scanner.nextLine().substring("Commission: ".length()));
                    int monthlyCommissionLimit = Integer.parseInt(scanner.nextLine().substring("Monthly Commission Limit: ".length()));
                    employee = new Dealer(pesel, firstName, lastName, position, salary, phoneNumber, commission, monthlyCommissionLimit);
                } else {
                    System.out.println("Invalid employee type: " + employeeType);
                    continue;
                }
                employeeList.add(employee);
            }
        }
    }

    public void backupToFile(char archiveType) {
        try {
            switch (archiveType) {
                case 'Z':
                    try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(fileName + ".zip"));
                         PrintWriter out = new PrintWriter(new OutputStreamWriter(zos))) {
                        ZipEntry ze = new ZipEntry(fileName);
                        zos.putNextEntry(ze);
                        for (Employee employee : employeeList) {
                            out.println(employee);
                        }
                    }
                    break;
                case 'G':
                    try (GZIPOutputStream gzos = new GZIPOutputStream(new FileOutputStream(fileName + ".gz"));
                         PrintWriter out = new PrintWriter(new OutputStreamWriter(gzos))) {
                        for (Employee employee : employeeList) {
                            out.println(employee);
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
            }
        } catch (IOException e) {
            System.out.println("Error saving employees: " + e.getMessage());
        }
    }
}