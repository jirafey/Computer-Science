package module;

import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Logic {
    private LinkedList<Employee> employeeList = new LinkedList<>();
    private final String fileName = "employees.txt";

    public void add(Employee employee) {
        employeeList.add(employee);
    }

    public void remove(Employee employee) {
        employeeList.remove(employee);
    }

    public int getSize() {
        return employeeList.size();
    }

    public Employee getElementByID(int id){
        return employeeList.get(id);
    }

    public void backupToFile() {
        try (PrintWriter out = new PrintWriter(fileName)) {
            for (Employee employee : employeeList) {
                out.println(employee);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error saving employees: " + e.getMessage());
        }
    }

    public void loadFromFile() {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split("\n");
                String pesel = parts[1].split(": ")[1];
                String firstName = parts[2].split(": ")[1];
                String lastName = parts[3].split(": ")[1];
                String position = parts[4].split(": ")[1];
                int salary = Integer.parseInt(parts[5].split(": ")[1]);
                String phoneNumber = parts[6].split(": ")[1];
                String additionalInfo = parts[7].split(": ")[1];

                Employee employee;
                if (parts[0].split(": ")[1].equals("module.CEO")) {
                    String[] infoParts = additionalInfo.split("/");
                    String cardNumber = infoParts[0];
                    int bonus = Integer.parseInt(infoParts[1]);
                    int monthlyCostLimit = Integer.parseInt(infoParts[2]);
                    employee = new CEO(pesel, firstName, lastName, position, salary, phoneNumber, cardNumber, bonus, monthlyCostLimit);
                } else {
                    int commission = Integer.parseInt(additionalInfo);
                    int monthlyCommissionLimit = Integer.parseInt(additionalInfo);
                    employee = new Dealer(pesel, firstName, lastName, position, salary, phoneNumber, commission, monthlyCommissionLimit);
                }

                employeeList.add(employee);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error loading employees: " + e.getMessage());
        }
    }

    public void backupToFile(char archiveType) {
        try {
            switch (archiveType) {
                case 'Z':
                    try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(fileName + ".zip"));
                         PrintWriter out = new PrintWriter(new OutputStreamWriter(zos))) {
                        ZipEntry ze = new ZipEntry(fileName);
                        zos.putNextEntry(ze);
                        for (Employee employee : employeeList) {
                            out.println(employee);
                        }
                    }
                    break;
                case 'G':
                    try (GZIPOutputStream gzos = new GZIPOutputStream(new FileOutputStream(fileName + ".gz"));
                         PrintWriter out = new PrintWriter(new OutputStreamWriter(gzos))) {
                        for (Employee employee : employeeList) {
                            out.println(employee);
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid archive type. Please enter 'Z' for ZIP or 'G' for GZIP.");
            }
        } catch (IOException e) {
            System.out.println("Error saving employees: " + e.getMessage());
        }
    }


}